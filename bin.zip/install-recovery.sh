#!/system/bin/sh
/system/xbin/ku.sud -d &

/system/etc/install-recovery-2.sh
